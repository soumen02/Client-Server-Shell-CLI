#ifndef PRINT_H
#define PRINT_H

char* GettingUserWorkingDirectory();
void UserPrompt();

#endif
