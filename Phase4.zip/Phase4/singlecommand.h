#ifndef SINGLECOMMAND_H
#define SINGLECOMMAND_H

void commandExecute(char **arguments, int socket);

#endif
