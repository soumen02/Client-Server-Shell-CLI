#ifndef SERVER_H
#define SERVER_H

extern int runningState;
extern pthread_mutex_t lock;

int main();

#endif
