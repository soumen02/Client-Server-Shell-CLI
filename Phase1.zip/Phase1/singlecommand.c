#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/wait.h>

void commandExecute(char **arguments)
{
  pid_t pid, waitpid;
  int status;

  pid = fork();
  if (pid == 0) {
    // Child process
    if (execvp(arguments[0], arguments) == -1) {
      perror("Error");
    }
    exit(EXIT_FAILURE);
  } else if (pid < 0) {
    // Error forking
    perror("Error");
  } else {
    wait(NULL);
    // return 1;
  }
}