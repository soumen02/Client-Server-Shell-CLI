//OS Assignment 
//Phase 1 Local CLI 
//Dev Kalavadiya and Soumen Mohanty

// Importing necessary libraries
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/wait.h>

// Including the header files
#include "print.h"
#include "read.h"
#include "splitter.h"
#include "checkpipe.h"
#include "singlecommand.h"
#include "pipe.h"

#define clear() printf("\033[H\033[J") // Clearing the screen 

int main(int argc, char const *argv[]) { 
  int commandFlag = 0, pipeFlag = -1; // Flags to control the pipe and command input functions
  char *command; // command is the string input read from the user 
  char **argument1, **argument2, **argument3, **argument4, **arguments; // to send the parsed arguments to the pipe 
  char **pipe_cmd; // array of each arguments 
  clear(); // clears the terminal
  printf("\t\t\t Welcome to D&S Shell\n");
  printf("\t ---------------------------------------------\n");
  printf("\t Enter your linux shell command to use our shell\n");
  printf("\t Enter <help> for the list of commands\n");
  printf("\t Enter <exit> to leave the shell\n\n");

  while(1){ // running till terminated 
    UserPrompt();
    command = readInput();
  
    char* exitString = "exit"; 
    if(strcmp(command,exitString) == 0){ // comapring the command entered to the exit string 
      printf("Exiting shell successfully  \n"); 
      exit(EXIT_SUCCESS);
    }
    char* helpString = "help";
    if(strcmp(command,helpString) == 0){ // comapring the command entered to the help string 
        printf("\tHere is the list of few shell commands you can enter: \n"); //printing the help menu
        printf("\tls: Command to display the files in a directory\n");
        printf("\ttouch: Command to create a file \n");
        printf("\tmkdir: Command to create a folder \n");
        printf("\tpwd: Command to print the current directory \n");
        printf("\trm: Command to remove objects \n");
        printf("\tcp: Command to copy  \n");
        printf("\trmdir: Command to remove a directory \n");
        printf("\tgrep: Command to search for a string of characters in a file \n");
        printf("\twc: Command to find the word count \n");
        printf("\tfind: Command that locates an object \n");
        printf("\tmv: Command that moves an object \n");
        printf("\tcat: Command that outputs the contents of a file \n");
        printf("\tps: Command that displays the running processes \n");
        printf("\tdf: Command to display the display the available disk space \n");
        printf("\twhoami: Command to print the name of the current user \n");
        printf("\t ------Pipes------\n");
        printf("\tOur shell allows maximum of 3 pipes\n");
        printf("\tSingle Pipe: eg. ls | grep c\n");
        printf("\tDouble Pipe: eg. ls -l | grep d | wc -c\n");
        printf("\tTripple Pipe: eg. cat xyz.txt | grep r | tee abc.txt | wc -l \n");
        // break;
    }

    pipeFlag = checkPipe(command); // Checks the number of pipes in the input and returns an Integer

    if (pipeFlag==0){ // If there are no pipes 
      arguments = lineSplitter(command); // get the arguments array from the line spliter (parsing)
      commandExecute(arguments); // execute the single command 
      free(arguments); // free the arugments after using since the array was dynamically allocated
    }
    else if (pipeFlag > 0) // if there is a pipe 
    {
        if (pipeFlag > 3){
            printf("Sorry, You have entered more than 3 pipes\n");
            break;
        }

        pipe_cmd = pipeSplitter(command); // use the pipe splitter to get the array of commands parsed by the pipe delimiter
  
     if (pipeFlag == 1){ // if there is one pipe
     // Basically we are getting the whole string split from the pipe and then splitting that further example "ls -l" -> ["ls","-l"]
        argument1 = lineSplitter(pipe_cmd[0]); // getting the first argument from the pipe slitter and splitting that further into single arguments
        argument2 = lineSplitter(pipe_cmd[1]);

       singlepipeExecute(argument1, argument2); // send the 2 arguments into the single pipe function

        free(argument1); // free the arugments after using since they were dynamically allocated
        free(argument2);
       }
      
     if (pipeFlag == 2 && arguments!=NULL){ // if there is two pipe  and the input is not null
        argument1 = lineSplitter(pipe_cmd[0]);
        argument2 = lineSplitter(pipe_cmd[1]);
        argument3 = lineSplitter(pipe_cmd[2]);

        doublepipeExecute(argument1, argument2, argument3); // send the 3 arguments into the double pipe function
       
        free(argument1); // free the arugments after using since they were dynamically allocated
        free(argument2);
        free(argument3);
      }
      
     if (pipeFlag == 3 && arguments!=NULL){ // if there is three pipe and the input is not null
        argument1 = lineSplitter(pipe_cmd[0]);
        argument2 = lineSplitter(pipe_cmd[1]);
        argument3 = lineSplitter(pipe_cmd[2]);
        argument4 = lineSplitter(pipe_cmd[3]);
       
        triplepipeExecute(argument1, argument2, argument3, argument4); // send the 4 arguments into the triple pipe function

        free(argument1); // free the arugments after using since they were dynamically allocated
        free(argument2);
        free(argument3);
        free(argument4);

      }
    }
    free(command); // freeing the input string which was also dynamically allocated
  }
  return 0;
}